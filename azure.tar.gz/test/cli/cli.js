module.exports = require('../../lib/cli/cli.js');
