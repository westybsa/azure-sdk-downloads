# My Events Sample #

This is the code used in the following video:

http://channel9.msdn.com/Events/windowsazure/learn/Node-JS-in-Windows-Azure